#import <UIKit/UIKit.h>

// Minimal declarations of the private Preferences classes we need.
@interface PSListController : UIViewController {
	NSArray *_specifiers;
}
- (NSArray *)loadSpecifiersFromPlistName:(NSString *)name target:(id)target;
@end

@interface SPRootListController : PSListController
@end

@implementation SPRootListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
	}
	return _specifiers;
}

@end
