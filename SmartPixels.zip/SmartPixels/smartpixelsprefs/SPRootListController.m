#import <UIKit/UIKit.h>
#import <notify.h>

// Minimal declarations of the private Preferences classes we need.
@interface PSListController : UIViewController {
	NSArray *_specifiers;
}
- (NSArray *)loadSpecifiersFromPlistName:(NSString *)name target:(id)target;
@end

@interface SPRootListController : PSListController
- (void)showLog;
- (void)testNow;
@end

@implementation SPRootListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
	}
	return _specifiers;
}

- (void)showLog {
	CFPreferencesAppSynchronize(CFSTR("com.example.smartpixels"));
	NSArray *now = (NSArray *)CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("debugLog"), CFSTR("com.example.smartpixels")));
	NSArray *prev = (NSArray *)CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("debugLogPrev"), CFSTR("com.example.smartpixels")));

	NSMutableString *text = [NSMutableString string];
	[text appendString:@"== this session ==\n"];
	[text appendString:now.count ? [now componentsJoinedByString:@"\n"] : @"(empty: the tweak has not written anything, so it is probably not loading into SpringBoard)"];
	if (prev.count) {
		[text appendString:@"\n\n== previous session ==\n"];
		[text appendString:[prev componentsJoinedByString:@"\n"]];
	}
	NSString *copy = [text copy];

	UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"SmartPixels log"
	                                                               message:copy
	                                                        preferredStyle:UIAlertControllerStyleAlert];
	[alert addAction:[UIAlertAction actionWithTitle:@"Copy" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
		UIPasteboard.generalPasteboard.string = copy;
	}]];
	[alert addAction:[UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleCancel handler:nil]];
	[self presentViewController:alert animated:YES completion:nil];
}

- (void)testNow {
	notify_post("com.example.smartpixels/prefs");
}

@end
