#import <UIKit/UIKit.h>
#import <notify.h>

// Minimal declarations of the private Preferences classes we need.
@interface PSListController : UIViewController {
	NSArray *_specifiers;
}
- (NSArray *)loadSpecifiersFromPlistName:(NSString *)name target:(id)target;
@end

@interface SPRootListController : PSListController
- (void)showLog;
- (void)testNow;
@end

@implementation SPRootListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
	}
	return _specifiers;
}

- (void)showLog {
	CFPreferencesAppSynchronize(CFSTR("com.example.smartpixels"));
	NSArray *lines = (NSArray *)CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("debugLog"), CFSTR("com.example.smartpixels")));
	NSString *text = lines.count
		? [lines componentsJoinedByString:@"\n"]
		: @"(no log yet: the tweak has not written anything since install, so it is probably not loading into SpringBoard)";
	UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"SmartPixels log"
	                                                               message:text
	                                                        preferredStyle:UIAlertControllerStyleAlert];
	[alert addAction:[UIAlertAction actionWithTitle:@"Copy" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
		UIPasteboard.generalPasteboard.string = text;
	}]];
	[alert addAction:[UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleCancel handler:nil]];
	[self presentViewController:alert animated:YES completion:nil];
}

- (void)testNow {
	notify_post("com.example.smartpixels/prefs");
}

@end
