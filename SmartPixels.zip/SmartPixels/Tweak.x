// SmartPixels for iOS (SpringBoard tweak, rootless / Dopamine)
// Draws a pass-through, top-level window containing a full-screen bitmap of
// opaque black pixels (1:1 with the render resolution). On OLED panels black
// pixels emit no light.

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/QuartzCore.h>
#import <stdarg.h>

#define PREF_DOMAIN  CFSTR("com.example.smartpixels")
#define PREF_NOTIFY  CFSTR("com.example.smartpixels/prefs")
#define LOG_PATH     @"/var/mobile/SmartPixels.log"

static void SPLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);
static void SPLog(NSString *fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
	va_end(ap);
	NSLog(@"[SmartPixels] %@", msg);
	NSString *line = [NSString stringWithFormat:@"%@ %@\n", [NSDate date], msg];
	NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LOG_PATH];
	if (!fh) {
		[line writeToFile:LOG_PATH atomically:NO encoding:NSUTF8StringEncoding error:nil];
		return;
	}
	[fh seekToEndOfFile];
	[fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
	[fh closeFile];
}

@interface UIWindow (SPPrivate)
- (void)_setSecure:(BOOL)secure;
@end

@interface SPWindow : UIWindow
@end

@implementation SPWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
- (BOOL)canBecomeKeyWindow { return NO; }
@end

static SPWindow *overlay = nil;
static UIView   *patternView = nil;
static NSTimer  *shiftTimer = nil;

static BOOL      prefEnabled = YES;
static NSInteger prefMode = 0;          // 0: 50% checker, 1: 25%, 2: 12.5%
static NSInteger prefShiftMinutes = 5;  // 0 = never
static NSInteger phase = 0;             // 0..3, moves the pattern 1px

static id getPref(CFStringRef key) {
	CFPreferencesAppSynchronize(PREF_DOMAIN);
	return CFBridgingRelease(CFPreferencesCopyAppValue(key, PREF_DOMAIN));
}

static void loadPrefs(void) {
	id e = getPref(CFSTR("enabled"));
	id m = getPref(CFSTR("mode"));
	id s = getPref(CFSTR("shiftMinutes"));
	prefEnabled      = e ? [e boolValue] : YES;
	prefMode         = m ? [m integerValue] : 0;
	prefShiftMinutes = s ? [s integerValue] : 5;
}

// Full-screen RGBA bitmap, 1 bitmap pixel = 1 render pixel. Black = opaque, rest transparent.
static CGImageRef createPatternImage(size_t W, size_t H, NSInteger mode, NSInteger ph) {
	CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
	CGContextRef ctx = CGBitmapContextCreate(NULL, W, H, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaPremultipliedLast);
	CGColorSpaceRelease(cs);
	if (!ctx) return NULL;

	uint8_t *data = (uint8_t *)CGBitmapContextGetData(ctx);
	size_t bpr = CGBitmapContextGetBytesPerRow(ctx);
	if (!data) { CGContextRelease(ctx); return NULL; }
	memset(data, 0, bpr * H);

	NSInteger px = ph % 2, py = ph / 2;
	for (size_t y = 0; y < H; y++) {
		uint8_t *row = data + y * bpr;
		for (size_t x = 0; x < W; x++) {
			NSInteger xi = (NSInteger)x, yi = (NSInteger)y;
			BOOL black;
			switch (mode) {
				case 0:  black = (((xi + px) + (yi + py)) % 2 == 0); break;
				case 1:  black = (((xi + px) % 2 == 0) && ((yi + py) % 2 == 0)); break;
				default: black = (((xi + px * 2) % 4 == 0) && ((yi + py) % 2 == 0)); break;
			}
			if (black) row[x * 4 + 3] = 255;   // premultiplied black: rgb 0, alpha 255
		}
	}
	CGImageRef img = CGBitmapContextCreateImage(ctx);
	CGContextRelease(ctx);
	return img;
}

static void applyPattern(void) {
	if (!overlay || !patternView) return;
	overlay.hidden = !prefEnabled;
	if (!prefEnabled) return;

	CGFloat scale = UIScreen.mainScreen.scale;
	CGSize size = UIScreen.mainScreen.bounds.size;
	size_t W = (size_t)lround(size.width * scale);
	size_t H = (size_t)lround(size.height * scale);

	CGImageRef img = createPatternImage(W, H, prefMode, phase);
	if (img) {
		patternView.layer.contents = (__bridge id)img;
		CGImageRelease(img);
	}
	SPLog(@"pattern applied: %zux%zu mode=%ld phase=%ld image=%d", W, H, (long)prefMode, (long)phase, img != NULL);
}

static void restartTimer(void) {
	[shiftTimer invalidate];
	shiftTimer = nil;
	if (prefEnabled && prefShiftMinutes > 0) {
		shiftTimer = [NSTimer scheduledTimerWithTimeInterval:(prefShiftMinutes * 60.0)
		                                             repeats:YES
		                                               block:^(NSTimer *t) {
			phase = (phase + 1) % 4;
			applyPattern();
		}];
	}
}

static void createOverlay(void) {
	if (overlay) return;
	CGRect bounds = UIScreen.mainScreen.bounds;
	SPLog(@"creating overlay, bounds=%@ scale=%.1f scenes=%lu",
	      NSStringFromCGRect(bounds), UIScreen.mainScreen.scale,
	      (unsigned long)UIApplication.sharedApplication.connectedScenes.count);

	overlay = [[SPWindow alloc] initWithFrame:bounds];
	overlay.windowLevel = 10000000;          // above status bar, alerts, lock screen
	overlay.userInteractionEnabled = NO;
	overlay.backgroundColor = UIColor.clearColor;
	overlay.opaque = NO;
	if ([overlay respondsToSelector:@selector(_setSecure:)]) [overlay _setSecure:YES];

	UIViewController *vc = [UIViewController new];
	vc.view.backgroundColor = UIColor.clearColor;
	vc.view.userInteractionEnabled = NO;
	overlay.rootViewController = vc;

	patternView = [[UIView alloc] initWithFrame:bounds];
	patternView.userInteractionEnabled = NO;
	patternView.opaque = NO;
	patternView.backgroundColor = UIColor.clearColor;
	patternView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	patternView.layer.contentsScale = UIScreen.mainScreen.scale;
	patternView.layer.contentsGravity = kCAGravityResize;
	patternView.layer.magnificationFilter = kCAFilterNearest;
	patternView.layer.minificationFilter = kCAFilterNearest;
	[vc.view addSubview:patternView];

	overlay.hidden = NO;
	applyPattern();
	restartTimer();
	SPLog(@"overlay created, hidden=%d level=%.0f", overlay.hidden, overlay.windowLevel);
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFNotificationName n, const void *obj, CFDictionaryRef u) {
	loadPrefs();
	dispatch_async(dispatch_get_main_queue(), ^{
		applyPattern();
		restartTimer();
	});
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
	%orig;
	SPLog(@"SpringBoard applicationDidFinishLaunching");
	dispatch_async(dispatch_get_main_queue(), ^{ createOverlay(); });
}
%end

%ctor {
	[[NSData data] writeToFile:LOG_PATH atomically:NO];   // fresh log each SpringBoard launch
	SPLog(@"loaded into %@", NSBundle.mainBundle.bundleIdentifier);
	loadPrefs();
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
		NULL, prefsChanged, PREF_NOTIFY, NULL, CFNotificationSuspensionBehaviorCoalesce);

	// Fallback in case the launch hook doesn't fire.
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)),
	               dispatch_get_main_queue(), ^{ createOverlay(); });
}
