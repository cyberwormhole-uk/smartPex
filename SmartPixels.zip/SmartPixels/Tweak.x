// SmartPixels for iOS (SpringBoard tweak, rootless / Dopamine)
// Draws a pass-through, top-level window containing a tiled pattern of
// opaque black pixels. On OLED panels black pixels emit no light.

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>

#define PREF_DOMAIN  CFSTR("com.example.smartpixels")
#define PREF_NOTIFY  CFSTR("com.example.smartpixels/prefs")

@interface UIWindow (SPPrivate)
- (void)_setSecure:(BOOL)secure;
@end

@interface SPWindow : UIWindow
@end

@implementation SPWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
- (BOOL)canBecomeKeyWindow { return NO; }
@end

static SPWindow *overlay = nil;
static UIView   *patternView = nil;
static NSTimer  *shiftTimer = nil;

static BOOL      prefEnabled = YES;
static NSInteger prefMode = 0;          // 0: 50% checker, 1: 25%, 2: 12.5%
static NSInteger prefShiftMinutes = 5;  // 0 = never
static NSInteger phase = 0;             // 0..3, moves the pattern 1px

static id getPref(CFStringRef key) {
	CFPreferencesAppSynchronize(PREF_DOMAIN);
	return CFBridgingRelease(CFPreferencesCopyAppValue(key, PREF_DOMAIN));
}

static void loadPrefs(void) {
	id e = getPref(CFSTR("enabled"));
	id m = getPref(CFSTR("mode"));
	id s = getPref(CFSTR("shiftMinutes"));
	prefEnabled      = e ? [e boolValue] : YES;
	prefMode         = m ? [m integerValue] : 0;
	prefShiftMinutes = s ? [s integerValue] : 5;
}

// Builds a tiny tile image (in real device pixels) that is repeated over the screen.
static UIImage *makeTile(NSInteger mode, NSInteger ph) {
	CGFloat scale = UIScreen.mainScreen.scale;
	size_t tw = (mode == 2) ? 4 : 2;
	size_t th = 2;
	int px = ph % 2, py = ph / 2;

	CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
	CGContextRef ctx = CGBitmapContextCreate(NULL, tw, th, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaPremultipliedLast);
	CGColorSpaceRelease(cs);
	if (!ctx) return nil;

	CGContextClearRect(ctx, CGRectMake(0, 0, tw, th));
	CGContextSetRGBFillColor(ctx, 0, 0, 0, 1);
	for (size_t y = 0; y < th; y++) {
		for (size_t x = 0; x < tw; x++) {
			BOOL black = NO;
			switch (mode) {
				case 0: black = (((x + px) + (y + py)) % 2 == 0); break;
				case 1: black = (((x + px) % 2 == 0) && ((y + py) % 2 == 0)); break;
				default: black = (((x + px * 2) % 4 == 0) && ((y + py) % 2 == 0)); break;
			}
			if (black) CGContextFillRect(ctx, CGRectMake(x, y, 1, 1));
		}
	}
	CGImageRef cg = CGBitmapContextCreateImage(ctx);
	CGContextRelease(ctx);
	if (!cg) return nil;
	UIImage *img = [UIImage imageWithCGImage:cg scale:scale orientation:UIImageOrientationUp];
	CGImageRelease(cg);
	return img;
}

static void applyPattern(void) {
	if (!overlay || !patternView) return;
	overlay.hidden = !prefEnabled;
	UIImage *tile = makeTile(prefMode, phase);
	if (tile) patternView.backgroundColor = [UIColor colorWithPatternImage:tile];
}

static void restartTimer(void) {
	[shiftTimer invalidate];
	shiftTimer = nil;
	if (prefEnabled && prefShiftMinutes > 0) {
		shiftTimer = [NSTimer scheduledTimerWithTimeInterval:(prefShiftMinutes * 60.0)
		                                             repeats:YES
		                                               block:^(NSTimer *t) {
			phase = (phase + 1) % 4;
			applyPattern();
		}];
	}
}

static void createOverlay(void) {
	if (overlay) return;
	CGRect bounds = UIScreen.mainScreen.bounds;

	overlay = [[SPWindow alloc] initWithFrame:bounds];
	overlay.windowLevel = 10000000;          // above status bar, alerts, lock screen
	overlay.userInteractionEnabled = NO;
	overlay.backgroundColor = UIColor.clearColor;
	overlay.opaque = NO;
	if ([overlay respondsToSelector:@selector(_setSecure:)]) [overlay _setSecure:YES];

	UIViewController *vc = [UIViewController new];
	vc.view.backgroundColor = UIColor.clearColor;
	vc.view.userInteractionEnabled = NO;
	overlay.rootViewController = vc;

	patternView = [[UIView alloc] initWithFrame:bounds];
	patternView.userInteractionEnabled = NO;
	patternView.opaque = NO;
	patternView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[vc.view addSubview:patternView];

	applyPattern();
	restartTimer();
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFNotificationName n, const void *obj, CFDictionaryRef u) {
	loadPrefs();
	dispatch_async(dispatch_get_main_queue(), ^{
		applyPattern();
		restartTimer();
	});
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
	%orig;
	dispatch_async(dispatch_get_main_queue(), ^{ createOverlay(); });
}
%end

%ctor {
	loadPrefs();
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
		NULL, prefsChanged, PREF_NOTIFY, NULL, CFNotificationSuspensionBehaviorCoalesce);
}
