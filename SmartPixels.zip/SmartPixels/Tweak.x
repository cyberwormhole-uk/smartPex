// SmartPixels for iOS (SpringBoard tweak, rootless / Dopamine)
// Draws a pass-through, top-level window containing a full-screen bitmap of
// opaque black pixels (1:1 with the render resolution). On OLED panels black
// pixels emit no light. Density is arbitrary (10-85%) via an 8x8 Bayer matrix,
// which spreads the black pixels as evenly as possible.

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/QuartzCore.h>
#import <stdarg.h>

#define PREF_DOMAIN  CFSTR("com.example.smartpixels")
#define PREF_NOTIFY  CFSTR("com.example.smartpixels/prefs")
#define LOG_PATH     @"/var/mobile/SmartPixels.log"

static void SPLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);
static void SPLog(NSString *fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
	va_end(ap);
	NSLog(@"[SmartPixels] %@", msg);
	NSString *line = [NSString stringWithFormat:@"%@ %@\n", [NSDate date], msg];
	NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LOG_PATH];
	if (!fh) {
		[line writeToFile:LOG_PATH atomically:NO encoding:NSUTF8StringEncoding error:nil];
		return;
	}
	[fh seekToEndOfFile];
	[fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
	[fh closeFile];
}

@interface UIWindow (SPPrivate)
- (void)_setSecure:(BOOL)secure;
@end

@interface SPWindow : UIWindow
@end

@implementation SPWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
- (BOOL)canBecomeKeyWindow { return NO; }
@end

static SPWindow *overlay = nil;
static UIView   *patternView = nil;
static NSTimer  *shiftTimer = nil;

static NSTimer  *testTimer = nil;
static BOOL      testExpired = NO;

static BOOL      prefEnabled = YES;
static BOOL      prefTestMode = YES;     // safety: overlay auto-hides 15 s after it appears
static NSInteger prefDensity = 50;      // % of pixels turned black (5-90)
static NSInteger prefShiftMinutes = 5;  // 0 = never
static NSInteger phase = 0;             // 0..63, offsets the pattern for anti burn-in

static int bayer[8][8];

static void buildBayer(void) {
	int n = 1;
	bayer[0][0] = 0;
	while (n < 8) {
		for (int y = 0; y < n; y++) {
			for (int x = 0; x < n; x++) {
				int b = bayer[y][x] * 4;
				bayer[y][x]         = b;
				bayer[y][x + n]     = b + 2;
				bayer[y + n][x]     = b + 3;
				bayer[y + n][x + n] = b + 1;
			}
		}
		n *= 2;
	}
}

static id getPref(CFStringRef key) {
	CFPreferencesAppSynchronize(PREF_DOMAIN);
	return CFBridgingRelease(CFPreferencesCopyAppValue(key, PREF_DOMAIN));
}

static void loadPrefs(void) {
	id e = getPref(CFSTR("enabled"));
	id d = getPref(CFSTR("density"));
	id s = getPref(CFSTR("shiftMinutes"));
	id t = getPref(CFSTR("testMode"));
	prefTestMode     = t ? [t boolValue] : YES;
	prefEnabled      = e ? [e boolValue] : YES;
	prefDensity      = d ? [d integerValue] : 50;
	prefShiftMinutes = s ? [s integerValue] : 5;
	if (prefDensity < 5)  prefDensity = 5;
	if (prefDensity > 90) prefDensity = 90;
}

// Full-screen RGBA bitmap, 1 bitmap pixel = 1 render pixel. Black = opaque, rest transparent.
static CGImageRef createPatternImage(size_t W, size_t H, NSInteger density, NSInteger ph) {
	CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
	CGContextRef ctx = CGBitmapContextCreate(NULL, W, H, 8, 0, cs, (CGBitmapInfo)((uint32_t)kCGBitmapByteOrder32Little | (uint32_t)kCGImageAlphaPremultipliedFirst));
	CGColorSpaceRelease(cs);
	if (!ctx) return NULL;

	uint8_t *data = (uint8_t *)CGBitmapContextGetData(ctx);
	size_t bpr = CGBitmapContextGetBytesPerRow(ctx);
	if (!data) { CGContextRelease(ctx); return NULL; }
	memset(data, 0, bpr * H);

	int threshold = (int)((density * 64 + 50) / 100);   // pixels with bayer value < threshold go black
	int px = (int)(ph % 8), py = (int)(ph / 8) % 8;

	for (size_t y = 0; y < H; y++) {
		uint8_t *row = data + y * bpr;
		int by = ((int)y + py) & 7;
		for (size_t x = 0; x < W; x++) {
			int bx = ((int)x + px) & 7;
			if (bayer[by][bx] < threshold) row[x * 4 + 3] = 255;   // premultiplied black (BGRA, alpha is byte 3)
		}
	}
	CGImageRef img = CGBitmapContextCreateImage(ctx);
	CGContextRelease(ctx);
	return img;
}

static void applyPattern(void) {
	if (!overlay || !patternView) return;
	overlay.hidden = !prefEnabled || (prefTestMode && testExpired);
	if (overlay.hidden) return;

	CGFloat scale = UIScreen.mainScreen.scale;
	CGSize size = UIScreen.mainScreen.bounds.size;
	size_t W = (size_t)lround(size.width * scale);
	size_t H = (size_t)lround(size.height * scale);

	CGImageRef img = createPatternImage(W, H, prefDensity, phase);
	if (img) {
		patternView.layer.contents = (__bridge id)img;
		CGImageRelease(img);
	}
	SPLog(@"pattern applied: %zux%zu density=%ld%% phase=%ld image=%d", W, H, (long)prefDensity, (long)phase, img != NULL);
}

static void armTestTimer(void) {
	[testTimer invalidate];
	testTimer = nil;
	testExpired = NO;
	if (!prefTestMode) return;
	testTimer = [NSTimer scheduledTimerWithTimeInterval:15.0
	                                            repeats:NO
	                                              block:^(NSTimer *t) {
		testExpired = YES;
		if (overlay) overlay.hidden = YES;
		SPLog(@"test mode: overlay auto-hidden after 15s");
	}];
}

static void restartTimer(void) {
	[shiftTimer invalidate];
	shiftTimer = nil;
	if (prefEnabled && prefShiftMinutes > 0) {
		shiftTimer = [NSTimer scheduledTimerWithTimeInterval:(prefShiftMinutes * 60.0)
		                                             repeats:YES
		                                               block:^(NSTimer *t) {
			phase = (phase + 1) % 64;
			applyPattern();
		}];
	}
}

static void createOverlay(void) {
	if (overlay) return;
	CGRect bounds = UIScreen.mainScreen.bounds;
	SPLog(@"creating overlay, bounds=%@ scale=%.1f scenes=%lu",
	      NSStringFromCGRect(bounds), UIScreen.mainScreen.scale,
	      (unsigned long)UIApplication.sharedApplication.connectedScenes.count);

	overlay = [[SPWindow alloc] initWithFrame:bounds];
	overlay.windowLevel = 10000000;          // above status bar, alerts, lock screen
	overlay.userInteractionEnabled = NO;
	overlay.backgroundColor = UIColor.clearColor;
	overlay.opaque = NO;
	overlay.layer.opaque = NO;
	if ([overlay respondsToSelector:@selector(_setSecure:)]) [overlay _setSecure:YES];

	UIViewController *vc = [UIViewController new];
	vc.view.backgroundColor = UIColor.clearColor;
	vc.view.userInteractionEnabled = NO;
	overlay.rootViewController = vc;

	patternView = [[UIView alloc] initWithFrame:bounds];
	patternView.userInteractionEnabled = NO;
	patternView.opaque = NO;
	patternView.layer.opaque = NO;
	patternView.backgroundColor = UIColor.clearColor;
	patternView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	patternView.layer.contentsScale = UIScreen.mainScreen.scale;
	patternView.layer.contentsGravity = kCAGravityResize;
	patternView.layer.magnificationFilter = kCAFilterNearest;
	patternView.layer.minificationFilter = kCAFilterNearest;
	[vc.view addSubview:patternView];

	overlay.hidden = NO;
	armTestTimer();
	applyPattern();
	restartTimer();
	SPLog(@"overlay created, hidden=%d level=%.0f", overlay.hidden, overlay.windowLevel);
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFNotificationName n, const void *obj, CFDictionaryRef u) {
	loadPrefs();
	dispatch_async(dispatch_get_main_queue(), ^{
		armTestTimer();
		applyPattern();
		restartTimer();
	});
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
	%orig;
	SPLog(@"SpringBoard applicationDidFinishLaunching");
	dispatch_async(dispatch_get_main_queue(), ^{ createOverlay(); });
}
%end

%ctor {
	[[NSData data] writeToFile:LOG_PATH atomically:NO];   // fresh log each SpringBoard launch
	SPLog(@"loaded into %@", NSBundle.mainBundle.bundleIdentifier);
	buildBayer();
	loadPrefs();
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
		NULL, prefsChanged, PREF_NOTIFY, NULL, CFNotificationSuspensionBehaviorCoalesce);

	// Fallback in case the launch hook doesn't fire.
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)),
	               dispatch_get_main_queue(), ^{ createOverlay(); });
}
