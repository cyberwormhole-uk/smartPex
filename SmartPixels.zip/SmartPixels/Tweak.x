// SmartPixels for iOS (SpringBoard tweak, rootless / Dopamine)
// Draws pass-through, top-level windows containing a full-screen bitmap of
// opaque black pixels (1:1 with the render resolution). On OLED panels black
// pixels emit no light. Density is arbitrary (10-85%) via an 8x8 Bayer matrix.
//
// DIAGNOSTIC BUILD: logs to /var/mobile/SmartPixels.log AND to the preference
// domain, so Settings > SmartPixels > "Show diagnostic log" can display it.

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/QuartzCore.h>
#import <stdarg.h>

#define PREF_DOMAIN   CFSTR("com.example.smartpixels")
#define PREF_NOTIFY   CFSTR("com.example.smartpixels/prefs")
#define LOG_PATH      @"/var/mobile/SmartPixels.log"
#define TEST_SECONDS  30.0

// ---------------------------------------------------------------- logging

static NSMutableArray<NSString *> *logLines = nil;

static void SPLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);
static void SPLog(NSString *fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
	va_end(ap);
	NSLog(@"[SmartPixels] %@", msg);

	static NSDateFormatter *df = nil;
	static dispatch_once_t once;
	dispatch_once(&once, ^{
		df = [NSDateFormatter new];
		df.dateFormat = @"HH:mm:ss";
	});
	NSString *line = [NSString stringWithFormat:@"%@ %@", [df stringFromDate:[NSDate date]], msg];

	if (!logLines) logLines = [NSMutableArray array];
	[logLines addObject:line];
	while (logLines.count > 40) [logLines removeObjectAtIndex:0];
	CFPreferencesSetAppValue(CFSTR("debugLog"), (__bridge CFPropertyListRef)[logLines copy], PREF_DOMAIN);
	CFPreferencesAppSynchronize(PREF_DOMAIN);

	NSString *fileLine = [line stringByAppendingString:@"\n"];
	NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LOG_PATH];
	if (!fh) {
		[fileLine writeToFile:LOG_PATH atomically:NO encoding:NSUTF8StringEncoding error:nil];
		return;
	}
	[fh seekToEndOfFile];
	[fh writeData:[fileLine dataUsingEncoding:NSUTF8StringEncoding]];
	[fh closeFile];
}

// ---------------------------------------------------------------- window

@interface UIWindow (SPPrivate)
- (void)_setSecure:(BOOL)secure;
@end

@interface SPWindow : UIWindow
@end

@implementation SPWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
- (BOOL)canBecomeKeyWindow { return NO; }
@end

static NSMutableArray<SPWindow *> *overlays = nil;
static NSMutableArray<UIView *>   *patternViews = nil;
static NSTimer  *shiftTimer = nil;
static NSTimer  *testTimer = nil;
static BOOL      testExpired = NO;

static BOOL      prefEnabled = YES;
static BOOL      prefTestMode = YES;    // safety: overlay auto-hides TEST_SECONDS after it appears
static NSInteger prefDensity = 50;      // % of pixels turned black (5-90)
static NSInteger prefShiftMinutes = 5;  // 0 = never
static NSInteger phase = 0;             // 0..63, offsets the pattern for anti burn-in

static int bayer[8][8];

static void buildBayer(void) {
	int n = 1;
	bayer[0][0] = 0;
	while (n < 8) {
		for (int y = 0; y < n; y++) {
			for (int x = 0; x < n; x++) {
				int b = bayer[y][x] * 4;
				bayer[y][x]         = b;
				bayer[y][x + n]     = b + 2;
				bayer[y + n][x]     = b + 3;
				bayer[y + n][x + n] = b + 1;
			}
		}
		n *= 2;
	}
}

static id getPref(CFStringRef key) {
	CFPreferencesAppSynchronize(PREF_DOMAIN);
	return CFBridgingRelease(CFPreferencesCopyAppValue(key, PREF_DOMAIN));
}

static void loadPrefs(void) {
	id e = getPref(CFSTR("enabled"));
	id d = getPref(CFSTR("density"));
	id s = getPref(CFSTR("shiftMinutes"));
	id t = getPref(CFSTR("testMode"));
	prefEnabled      = e ? [e boolValue] : YES;
	prefDensity      = d ? [d integerValue] : 50;
	prefShiftMinutes = s ? [s integerValue] : 5;
	prefTestMode     = t ? [t boolValue] : YES;
	if (prefDensity < 5)  prefDensity = 5;
	if (prefDensity > 90) prefDensity = 90;
}

// Full-screen BGRA bitmap, 1 bitmap pixel = 1 render pixel. Black = opaque, rest transparent.
static CGImageRef createPatternImage(size_t W, size_t H, NSInteger density, NSInteger ph) {
	CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
	CGContextRef ctx = CGBitmapContextCreate(NULL, W, H, 8, 0, cs, (CGBitmapInfo)((uint32_t)kCGBitmapByteOrder32Little | (uint32_t)kCGImageAlphaPremultipliedFirst));
	CGColorSpaceRelease(cs);
	if (!ctx) return NULL;

	uint8_t *data = (uint8_t *)CGBitmapContextGetData(ctx);
	size_t bpr = CGBitmapContextGetBytesPerRow(ctx);
	if (!data) { CGContextRelease(ctx); return NULL; }
	memset(data, 0, bpr * H);

	int threshold = (int)((density * 64 + 50) / 100);   // pixels with bayer value < threshold go black
	int px = (int)(ph % 8), py = (int)(ph / 8) % 8;

	for (size_t y = 0; y < H; y++) {
		uint8_t *row = data + y * bpr;
		int by = ((int)y + py) & 7;
		for (size_t x = 0; x < W; x++) {
			int bx = ((int)x + px) & 7;
			if (bayer[by][bx] < threshold) row[x * 4 + 3] = 255;   // premultiplied black, alpha = byte 3
		}
	}
	CGImageRef img = CGBitmapContextCreateImage(ctx);
	CGContextRelease(ctx);
	return img;
}

static void applyPattern(void) {
	if (!overlays.count) return;
	BOOL hide = !prefEnabled || (prefTestMode && testExpired);
	for (SPWindow *w in overlays) w.hidden = hide;
	if (hide) return;

	CGFloat scale = UIScreen.mainScreen.scale;
	CGSize size = UIScreen.mainScreen.bounds.size;
	size_t W = (size_t)lround(size.width * scale);
	size_t H = (size_t)lround(size.height * scale);

	CGImageRef img = createPatternImage(W, H, prefDensity, phase);
	if (img) {
		for (UIView *v in patternViews) v.layer.contents = (__bridge id)img;
		CGImageRelease(img);
	}
	SPLog(@"pattern applied: %zux%zu density=%ld%% phase=%ld image=%d windows=%lu",
	      W, H, (long)prefDensity, (long)phase, img != NULL, (unsigned long)overlays.count);
}

static void armTestTimer(void) {
	[testTimer invalidate];
	testTimer = nil;
	testExpired = NO;
	if (!prefTestMode) return;
	testTimer = [NSTimer scheduledTimerWithTimeInterval:TEST_SECONDS
	                                            repeats:NO
	                                              block:^(NSTimer *t) {
		testExpired = YES;
		for (SPWindow *w in overlays) w.hidden = YES;
		SPLog(@"test mode: overlay auto-hidden after %.0fs", TEST_SECONDS);
	}];
}

static void restartTimer(void) {
	[shiftTimer invalidate];
	shiftTimer = nil;
	if (prefEnabled && prefShiftMinutes > 0) {
		shiftTimer = [NSTimer scheduledTimerWithTimeInterval:(prefShiftMinutes * 60.0)
		                                             repeats:YES
		                                               block:^(NSTimer *t) {
			phase = (phase + 1) % 64;
			applyPattern();
		}];
	}
}

static void buildOverlay(UIWindowScene *scene) {
	CGRect bounds = UIScreen.mainScreen.bounds;
	SPWindow *w = scene ? [[SPWindow alloc] initWithWindowScene:scene] : [[SPWindow alloc] initWithFrame:bounds];
	w.frame = bounds;
	w.windowLevel = 10000000;          // above status bar, alerts, lock screen
	w.userInteractionEnabled = NO;
	w.backgroundColor = UIColor.clearColor;
	w.opaque = NO;
	w.layer.opaque = NO;
	if ([w respondsToSelector:@selector(_setSecure:)]) [w _setSecure:YES];

	UIViewController *vc = [UIViewController new];
	vc.view.backgroundColor = UIColor.clearColor;
	vc.view.userInteractionEnabled = NO;
	w.rootViewController = vc;

	UIView *pv = [[UIView alloc] initWithFrame:bounds];
	pv.userInteractionEnabled = NO;
	pv.opaque = NO;
	pv.layer.opaque = NO;
	pv.backgroundColor = UIColor.clearColor;
	pv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	pv.layer.contentsScale = UIScreen.mainScreen.scale;
	pv.layer.contentsGravity = kCAGravityResize;
	pv.layer.magnificationFilter = kCAFilterNearest;
	pv.layer.minificationFilter = kCAFilterNearest;
	[vc.view addSubview:pv];

	w.hidden = NO;
	[overlays addObject:w];
	[patternViews addObject:pv];
}

static void createOverlay(void) {
	if (overlays) return;
	overlays = [NSMutableArray array];
	patternViews = [NSMutableArray array];

	UIWindowScene *scene = nil;
	for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
		if ([s isKindOfClass:[UIWindowScene class]]) { scene = (UIWindowScene *)s; break; }
	}
	SPLog(@"creating overlays: bounds=%@ scale=%.1f connectedScenes=%lu windowScene=%@",
	      NSStringFromCGRect(UIScreen.mainScreen.bounds), UIScreen.mainScreen.scale,
	      (unsigned long)UIApplication.sharedApplication.connectedScenes.count, scene ? @"found" : @"none");

	buildOverlay(nil);                 // window A: plain frame window
	if (scene) buildOverlay(scene);    // window B: attached to a window scene

	armTestTimer();
	applyPattern();
	restartTimer();

	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		for (NSUInteger i = 0; i < overlays.count; i++) {
			SPWindow *w = overlays[i];
			SPLog(@"overlay %lu: hidden=%d hasScene=%d hasScreen=%d level=%.0f alpha=%.2f frame=%@",
			      (unsigned long)i, w.hidden, w.windowScene != nil, w.screen != nil,
			      w.windowLevel, w.alpha, NSStringFromCGRect(w.frame));
		}
	});
}

static void refreshOverlay(BOOL rearm) {
	createOverlay();                    // no-op if already created
	if (rearm) armTestTimer();
	applyPattern();
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFNotificationName n, const void *obj, CFDictionaryRef u) {
	loadPrefs();
	dispatch_async(dispatch_get_main_queue(), ^{
		refreshOverlay(YES);
		restartTimer();
	});
}

static void screenEvent(CFNotificationCenterRef c, void *o, CFNotificationName n, const void *obj, CFDictionaryRef u) {
	dispatch_async(dispatch_get_main_queue(), ^{
		if (overlays.count) refreshOverlay(YES);   // show the overlay again for the test window
	});
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
	%orig;
	SPLog(@"SpringBoard applicationDidFinishLaunching");
	dispatch_async(dispatch_get_main_queue(), ^{ createOverlay(); });
}
%end

%ctor {
	[[NSData data] writeToFile:LOG_PATH atomically:NO];   // fresh log each SpringBoard launch
	logLines = [NSMutableArray array];
	SPLog(@"loaded into %@", NSBundle.mainBundle.bundleIdentifier);
	buildBayer();
	loadPrefs();

	CFNotificationCenterRef darwin = CFNotificationCenterGetDarwinNotifyCenter();
	CFNotificationCenterAddObserver(darwin, NULL, prefsChanged, PREF_NOTIFY, NULL, CFNotificationSuspensionBehaviorCoalesce);
	CFNotificationCenterAddObserver(darwin, NULL, screenEvent, CFSTR("com.apple.iokit.hid.displayStatus"), NULL, CFNotificationSuspensionBehaviorCoalesce);
	CFNotificationCenterAddObserver(darwin, NULL, screenEvent, CFSTR("com.apple.springboard.lockstate"), NULL, CFNotificationSuspensionBehaviorCoalesce);

	// Fallback in case the launch hook doesn't fire.
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)),
	               dispatch_get_main_queue(), ^{ createOverlay(); });
}
