# SmartPixels (iOS, rootless)

Build (needs Theos + iOS SDK on your Mac/Linux box):

    export THEOS=~/theos
    make package

The .deb lands in ./packages. Install it with Sileo (open the file) or:

    scp packages/*.deb mobile@<phone-ip>:/var/mobile/
    ssh root@<phone-ip> "dpkg -i /var/mobile/com.example.smartpixels*.deb && sbreload"

Needs `preferenceloader` (install from Sileo) for the Settings page.
Change `com.example.smartpixels` everywhere if you want your own bundle ID.
